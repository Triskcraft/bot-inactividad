import { DateTime, Duration } from 'luxon';

/**
 * Intenta interpretar un texto como duracion o fecha absoluta.
 * @param {string} input Texto ingresado por el usuario.
 * @param {Date} [now]
 * @returns {{ until: DateTime, isDuration: boolean }}
 */
export function parseUserTime(input, now = new Date()) {
  const trimmed = input.trim();
  const base = DateTime.fromJSDate(now).toUTC();

  const duration = parseDuration(trimmed);
  if (duration) {
    return { until: base.plus(duration), isDuration: true };
  }

  const absolute = parseAbsolute(trimmed, base.zone);
  if (absolute) {
    return { until: absolute, isDuration: false };
  }

  throw new Error('No se pudo interpretar la fecha o duración proporcionada. Usa ejemplos como "3d", "2h30m" o "2024-05-31 18:00".');
}

function parseDuration(value) {
  const regex = /^\s*(?:(\d+)\s*d)?\s*(?:(\d+)\s*h)?\s*(?:(\d+)\s*m)?\s*(?:(\d+)\s*s)?\s*$/i;
  const match = value.match(regex);
  if (!match) {
    return null;
  }

  const [, days, hours, minutes, seconds] = match.map((segment) => (segment ? Number.parseInt(segment, 10) : 0));
  if (!days && !hours && !minutes && !seconds) {
    return null;
  }

  return Duration.fromObject({ days, hours, minutes, seconds });
}

function parseAbsolute(value, zone) {
  const patterns = [
    "yyyy-MM-dd HH:mm",
    "yyyy-MM-dd'T'HH:mm",
    "yyyy-MM-dd",
    "dd/MM/yyyy HH:mm",
    "dd/MM/yyyy",
  ];

  for (const format of patterns) {
    const dt = DateTime.fromFormat(value, format, { zone });
    if (dt.isValid) {
      return dt.toUTC();
    }
  }

  const iso = DateTime.fromISO(value, { zone });
  if (iso.isValid) {
    return iso.toUTC();
  }

  return null;
}

/**
 * Formatea una fecha para presentar al usuario en su huso horario.
 * @param {DateTime} until
 * @returns {string}
 */
export function formatForUser(until) {
  return `<t:${Math.floor(until.toSeconds())}:F> (restan <t:${Math.floor(until.toSeconds())}:R>)`;
}
